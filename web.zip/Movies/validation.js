function tel(){
    var Reg = document.forms["Reg-form"]["Reg-no"].value;
    
    
    if (Reg ==1623152001) {
    
        document.getElementById("name").innerHTML="Hi Chithra";
        return false;
        if (Reg==1623152001) {
        
           document.getElementById("boox").innerHTML="Hello";
        }
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    
    if (Reg ==1623152002) {
    
        document.getElementById("name").innerHTML="Hi Ganga devi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152003) {
    
        document.getElementById("name").innerHTML="Hi Jessima ";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152004) {
    
        document.getElementById("name").innerHTML="Hi Abinesh ";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152005) {
    
        document.getElementById("name").innerHTML="Hi Akash Raj";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152006) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152007) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152008) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152009) {
    
        document.getElementById("name").innerHTML="Hi Batrick Raja Segar";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152010) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152011) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152012) {
    
        document.getElementById("name").innerHTML="Hi Gugan";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152013) {
    
        document.getElementById("name").innerHTML="Hi Harish";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152014) {
    
        document.getElementById("name").innerHTML="Hi Jegan";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152015) {
    
        document.getElementById("name").innerHTML="Hi Karthikeyan";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152016) {
    
        document.getElementById("name").innerHTML="Hi Lingesh waran";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152017) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152018) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152019) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152020) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152021) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152022) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152023) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152024) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152025) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152026) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152027) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152028) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152029) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152030) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152031) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
   if (Reg ==1623152032) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152033) {
    
        document.getElementById("name").innerHTML="Hi Vasanth Kumar";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
   if (Reg ==1623152034) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
  if (Reg ==1623152035) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }
    if (Reg ==1623152036) {
    
        document.getElementById("name").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="d";
    }  
     if (Reg ==1623152037) {
    
        document.getElementById("name").innerHTML="Hi Yogesh Waran .";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    }
    if (Reg ==1623152038) {
    
        document.getElementById("name").innerHTML="Hi Yogesh Waran .k";
        return false;
    }
    else{
        document.getElementById("name").innerHTML="check the Regno";
    } 
}
