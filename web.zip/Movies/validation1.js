function se(){
    var search = document.forms["search"]["check"].value;
    if (search==null || search=="") {
    document.getElementById("output").innerHTML="Enter The RegNo";
    return false;
        
    }
    
    
    if (search ==1623152001) {
    
        document.getElementById("output").innerHTML="Chithra";
        return false;
       
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    
    if (search ==1623152002) {
    
        document.getElementById("output").innerHTML="Ganga devi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152003) {
    
        document.getElementById("outut").innerHTML="Jessima ";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152004) {
    
        document.getElementById("output").innerHTML="Abinesh ";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152005) {
    
        document.getElementById("output").innerHTML="Akash Raj";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152006) {
    
        document.getElementById("output").innerHTML="Unname 6";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search==1623152007) {
    
        document.getElementById("output").innerHTML="Unname 7";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152008) {
    
        document.getElementById("output").innerHTML="Unname 8";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152009) {
    
        document.getElementById("output").innerHTML="Hi Batrick Raja Segar";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search  ==1623152010) {
    
        document.getElementById("output").innerHTML="Unname 10";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search  ==1623152011) {
    
        document.getElementById("output").innerHTML="Unname 11";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152012) {
    
        document.getElementById("output").innerHTML="Gugan";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152013) {
    
        document.getElementById("output").innerHTML="Harish";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152014) {
    
        document.getElementById("output").innerHTML="Jegan";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152015) {
    
        document.getElementById("output").innerHTML="Karthikeyan";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152016) {
    
        document.getElementById("output").innerHTML="Lingesh waran";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search  ==1623152017) {
    
        document.getElementById("output").innerHTML="Unname";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152018) {
    
        document.getElementById("output").innerHTML="Unname";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search  ==1623152019) {
    
        document.getElementById("output").innerHTML="Unname 19";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search  ==1623152020) {
    
        document.getElementById("output").innerHTML="Unname 20";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152021) {
    
        document.getElementById("output").innerHTML="Unname 21";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search  ==1623152022) {
    
        document.getElementById("output").innerHTML="Unname 22";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search  ==1623152023) {
    
        document.getElementById("output").innerHTML="Unname 23";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152024) {
    
        document.getElementById("output").innerHTML="Unname 24";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152025) {
    
        document.getElementById("output").innerHTML="Unname 25";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
    if (search ==1623152026) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
    if (search ==1623152027) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
    if (search ==1623152028) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
    if (search ==1623152029) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
    if (search ==1623152030) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
    if (search ==1623152031) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
   if (search ==1623152032) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
    if (search ==1623152033) {
    
        document.getElementById("output").innerHTML="Hi Vasanth Kumar";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
   if (search ==1623152034) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
  if (search ==1623152035) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }
    if (search ==1623152036) {
    
        document.getElementById("output").innerHTML="Hi";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="d";
    }  
     if (search ==1623152037) {
    
        document.getElementById("output").innerHTML="Hi Yogesh Waran .";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    }
    if (search ==1623152038) {
    
        document.getElementById("output").innerHTML="Hi Yogesh Waran .k";
        return false;
    }
    else{
        document.getElementById("output").innerHTML="check the Regno";
    } 
}
